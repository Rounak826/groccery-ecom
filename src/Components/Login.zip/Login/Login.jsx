import React, { useRef } from 'react';
import './login.css';
import { useState } from "react";
import illustration from '../../Assets/setup.svg';
import { Link, useNavigate } from "react-router-dom";
import { getAuth, RecaptchaVerifier,signInWithPhoneNumber } from "firebase/auth";
export default function Login() {
  let navigate = useNavigate();
    const [show, setShow] = useState(true);
    const [otpSent, setOtpSent] = useState(false);
    const mobilenoRef = useRef();
    const OtpRef = useRef();
    const [error, setError] = useState({ status: false, message: "" });
    const [loading, setLoading] = useState(false);
    const auth = getAuth();
    function invisibleRecaptcha() {
      console.log('capthca funcion');
      window.recaptchaVerifier = new RecaptchaVerifier('Recaptcha-container', {
        'size': 'invisible',
        'callback': (response) => {
          // reCAPTCHA solved, allow signInWithPhoneNumber.
          console.log('recaptcha done');
        }
      }, auth);
    }
    function handleSendOTP(e) {
      console.log('capthca funcion', mobilenoRef.current.value);
      e.preventDefault();
      invisibleRecaptcha();
      let appVerifier = window.recaptchaVerifier;
      signInWithPhoneNumber(auth, mobilenoRef.current.value, appVerifier).then(confirmationResult => {
        setOtpSent(true);
        console.log('Otp sent');
        window.confirmationResult = confirmationResult; 
  
      }).catch(e => console.log(e));
    }
    function handleSubmitOTP(e) {
      setLoading(true)
      e.preventDefault();
      console.log('submit otp');
      let confirmationResult = window.confirmationResult;
      confirmationResult.confirm(OtpRef.current.value).then((result) => {
        // User signed in successfully.
        console.log('athenticated');
        navigate('/')
        
        // ...
      }).catch((error) => {
        // User couldn't sign in (bad verification code?)
        setError()
      });
      setLoading(false);
    }
  return (
    <div className="login">
    <div className="illustration">
       <img src={illustration} alt="" />
    </div>
    <div className="form">
       <h2>login</h2>
       {show?emailloginForm(setShow, show): otpSent
            ? otpForm(setShow, show, OtpRef, handleSubmitOTP)
            : mobilelogin(setShow, show, mobilenoRef, handleSendOTP)}
    </div>
  </div>
  );
}
function otpForm(setShow, show, OtpRef, handleSubmitOTP) {
  return (
    <form action="">
      <div className="formInput">
        <label htmlFor="otp">Enter OTP No.</label>
        <input type="text" name="otp" ref={OtpRef} />
      </div>
      <button onClick={e => setShow(!show)} className="link">resend OTP</button>
      <button onClick={e => setShow(!show)} className="link">Use Email Instead</button>
      <div className="formRow">
        <button className="secondary">Login</button>
        <button className="primary" onClick={handleSubmitOTP}>Submit</button>
      </div>
    </form>
  );
}
function mobilelogin(setShow, show, mobilenoRef, handleSendOTP) {
  return (
    <form action="">
      <div className="formInput">
        <label htmlFor="Number">Enter Your Mobile No. </label>
        <input type="text" name="number" ref={mobilenoRef} />
      </div>

      <button onClick={e => setShow(!show)} className="link">Use Email Instead</button>
      <div className="formRow">
        <button className="secondary">Login</button>
        <button id="sendOtpBtn" onClick={handleSendOTP} className="primary">Send Otp</button>
      </div>
      <div id="Recaptcha-container"></div>
    </form>
  );
}
  function emailloginForm(setShow,show){
    return(
      <form action="">
            <div className="formInput">
              <label htmlFor="email">Email</label>
              <input type="Email" name="email" />
            </div>
            
            <div className="formInput">
              <label htmlFor="password">Password</label>
              <input type="Password" name="email" />
            </div>
  
            <button onClick={e=>setShow(!show)} className="link">Use Mobile Instead</button>
            <div className="formRow">
              <Link to='/signup' className="secondary">Signup</Link>
              <Link to='/' className="primary">login</Link>
            </div>
          </form>
    );
  }